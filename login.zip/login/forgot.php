<?php 
	include 'includes/finance_db_connect.php';
	include 'includes/session.php';

	$errors = array("email" => "");

	if($_SERVER["REQUEST_METHOD"] == "POST"){
		  function dataInput($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
          }

           $email = dataInput($_POST['email']);

           $stmt = $pdo->prepare("SELECT * FROM `admins` WHERE email = ?");
      	   $stmt->execute([$email]);


           if($stmt->rowCount() > 0){
            	header("location: recover.php");
    		} else {
    			$errors["email"] = "Email did not exist";
    		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Forgot Password</title>

	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="\test\finance\img\logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	<style>
		<?php include "login.css"; ?>
	</style>
</head>
<body>
	<h1 class="tech">Tech Innovation</h1>
	<section class="center">
		<div class="login">
			<span class="title">Forgot Password</span>
			<form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">	
				<div class="box">
					<i class="fa-solid fa-user"></i>
					<input type="text" name="email" placeholder="Email">
				</div>
				<span class="errors">
					<?php echo $errors["email"]; ?>
				</span>
				<input class="btn" type="submit" name="submit" value="submit">
			</form>
		</div>
	</section>
</body>
</html>