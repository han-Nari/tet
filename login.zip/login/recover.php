<?php 
	include 'includes/finance_db_connect.php';
	include 'includes/session.php';

	$errors = array("password" => "");


	if(isset($_POST["update"])) {
		function dataInput($data) {
	       $data = trim($data);
	       $data = stripslashes($data);
	       $data = htmlspecialchars($data);
	       return $data;
	    }

       $password = dataInput($_POST["password"]);
       $passwordCon = dataInput($_POST["passwordCon"]);

       if(empty($password)) {
          $errors["password"] = "password is empty!";
	      } elseif(strlen($password) < 10) {
	            $errors["password"] = "put at least 10 characters!";
	      } elseif($password != $passwordCon) {
	            $errors["password"] = "password must matched!";
	      } elseif(!preg_match('/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]+$/', $password)) {
	            $errors["password"] = "password consist of letters and numbers only!";
	      }
	   if(array_filter($errors)) {
            // If there's error the form wont submit!
	     } else {
	         // If there's no error the form will be submitted
	         $query = "UPDATE `admins` SET password = :password";
	         $hashPwd = password_hash($password, PASSWORD_BCRYPT);
	         $stmt = $pdo->prepare($query);
	         $stmt->bindParam(":password", $hashPwd);
	         $stmt->execute();
	            header('location:login.php');
	         }
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Recover Password</title>

	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="\test\finance\img\logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	<style>
		<?php include "login.css"; ?>
	</style>
</head>
<body>
	<h1 class="tech">Tech Innovation</h1>
	<section class="center">
		<div class="login">
			<span class="title">Recover Password</span>
			<form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">	
				<div class="box pwd">
					<i class="fa-solid fa-key"></i>
					<input type="password" id="password"  name="password" placeholder="Password">
					<div class="message">Password is <span id="strength"></span></div>
				</div>

				<span class="errors">
					<?php echo $errors["password"]; ?>
				</span>

				<div class="box pwd">
					<i class="fa-solid fa-key"></i>
					<input type="password" id="cpassword" name="passwordCon" placeholder="Password repeat">
					<div class="cmessage">Password is <span id="cstrength"></span></div>
				</div>

					<span class="errors">
					<?php echo $errors["password"]; ?>
				</span>

				<input class="btn" type="submit" name="update" value="Update">
			</form>
		</div>
	</section>

	<script src="passwordStr.js"></script>
</body>
</html>